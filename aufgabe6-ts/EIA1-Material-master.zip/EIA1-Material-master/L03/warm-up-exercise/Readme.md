Mit den Grundlagen zu HTML sollten Sie eine bestehende HTML Struktur in seinen grundlegenden Elementen verstehen können.



Dazu eine kleine Übung:

Hier finden Sie ein (gekürztes) Beispiel aus Wikipedia (ohne Styles).

1. Das Bild unter dem Titel wird nicht angezeigt. Können Sie das korrigieren?
2. Nach dem einführenden Textabschnitt (am Ende des Satzes "Explanations for the picture superiority effect are not concrete and are still being debated") soll ein Erklärvideo angezeigt werden. Suchen Sie sich ein passendes Video auf YouTube und betten Sie es ein.
3. In der HTML Datei finden Sie folgende Info "Cached time: 20211015174709". Was könnte damit gemeint sein?

