Das Bild "Ergebnis.png" zeigt Ihnen Elemente fünf Elemente in einem Seiten-Arrangement: ein horizontal mittig plaziertes Hauptelement, in dem in Textform die Pixelgröße dieses Hauptelements angezeigt wird, dann vier kleine Elemente (TL, TR, BL, BR), die jeweils innerhalb des Hauptelements in den Ecken verteilt werden. Versuchen Sie diese Darstellung mit den Positionierungsmöglichkeiten in CSS abzubilden.



Wenn Sie später noch Lust haben: mit dem Wissen zu komplexeren Selektionsmöglichkeiten können Sie auch jetzt alle Level von [CSS Diner](https://flukeout.github.io) spielen.
